<header>
  <div class="logo">سين ليانا 🏆</div>
  <button class="pass-btn" onclick="openPassModal()">🔑 إدخال كلمة السر</button>
</header>

<!-- Modal / واجهة كلمة السر -->
<div id="pass-modal" class="modal-overlay">
  <div class="modal-card">
    <h3>إدخال كلمة السر 🔑</h3>
    <p style="color:#ccc; font-size:0.9rem; margin-bottom:15px;">أدخل كلمة السر لتفعيل التحديات وإعادة تشغيل الأسئلة</p>
    <input type="password" id="pass-input" placeholder="أدخل كلمة السر هنا...">
    <div id="modal-msg" style="margin-bottom:15px; font-weight:bold; font-size:0.95rem;"></div>
    <div>
      <button class="btn" onclick="submitPassword()">تم / تفعيل</button>
      <button class="btn" style="background:#555;" onclick="closePassModal()">إلغاء</button>
    </div>
  </div>
</div>

<div class="container">

  <!-- الشاشة 1: الرئيسية -->
  <div id="home-screen" class="screen active" style="text-align:center; padding: 40px 0;">
    <h1 style="font-size:2.8rem; margin-bottom:15px; color:var(--primary);">لعبة سين ليانا</h1>
    <p style="margin-bottom:30px; color:#aaa;">المنافسة الأولى للمسابقات والألغاز الجماعية</p>
    <button class="btn" onclick="showScreen('teams-screen')">🎮 ابدأ اللعبة الآن</button>
  </div>

  <!-- الشاشة 2: الفرق ووسائل المساعدة -->
  <div id="teams-screen" class="screen">
    <div class="setup-box">
      <h2 style="font-size:1.8rem; margin-bottom:15px;">حدد معلومات الفرق</h2>
      <div>
        <input type="text" id="host-name" placeholder="اسم معلق / مدير اللعبة">
      </div>
      <div class="inputs-grid">
        <div>
          <h3>الفريق الأول</h3>
          <input type="text" id="team1-name" value="الفريق الأول">
          <p style="margin-top:10px; font-size:0.85rem; color:#aaa;">اختر وسائل المساعدة (يمكنك اختيارها كلها):</p>
          <div class="lifelines">
            <button class="lifeline-btn" onclick="toggleLifeline(this)">اتصال بصديق</button>
            <button class="lifeline-btn" onclick="toggleLifeline(this)">استبدال</button>
            <button class="lifeline-btn" onclick="toggleLifeline(this)">الحمرة</button>
            <button class="lifeline-btn" onclick="toggleLifeline(this)">تجنيب</button>
            <button class="lifeline-btn" onclick="toggleLifeline(this)">دبل نقاط</button>
          </div>
        </div>
        <div>
          <h3>الفريق الثاني</h3>
          <input type="text" id="team2-name" value="الفريق الثاني">
          <p style="margin-top:10px; font-size:0.85rem; color:#aaa;">اختر وسائل المساعدة (يمكنك اختيارها كلها):</p>
          <div class="lifelines">
            <button class="lifeline-btn" onclick="toggleLifeline(this)">اتصال بصديق</button>
            <button class="lifeline-btn" onclick="toggleLifeline(this)">استبدال</button>
            <button class="lifeline-btn" onclick="toggleLifeline(this)">الحمرة</button>
            <button class="lifeline-btn" onclick="toggleLifeline(this)">تجنيب</button>
            <button class="lifeline-btn" onclick="toggleLifeline(this)">دبل نقاط</button>
          </div>
        </div>
      </div>
      <button class="btn" onclick="goToCategories()">التالي: اختيار الفئات (8)</button>
    </div>
  </div>

  <!-- الشاشة 3: اختيار 8 فئات مقسمة -->
  <div id="categories-screen" class="screen">
    <h2 style="text-align:center;">اختر 8 فئات للعب (<span id="cat-count" style="color:var(--gold);">0</span>/8):</h2>
    <div id="categories-container"></div>
    <div style="text-align:center; margin-top:20px;">
      <button class="btn" onclick="startGame()">ابدأ اللعب 🚀</button>
    </div>
  </div>

  <!-- الشاشة 4: شبكة الأسئلة -->
  <div id="board-screen" class="screen">
    <div class="scoreboard">
      <div><span id="display-t1">الفريق 1</span>: <span id="score-1" style="color:var(--gold);">0</span></div>
      <div><span id="display-t2">الفريق 2</span>: <span id="score-2" style="color:var(--gold);">0</span></div>
    </div>
    <div class="board-grid" id="board-grid"></div>
  </div>

  <!-- الشاشة 5: عرض السؤال -->
  <div id="q-screen" class="screen">
    <div class="q-box">
      <h3 id="q-cat-title" style="color:var(--gold); font-size:1.4rem;"></h3>
      <div id="challenge-box" style="display:none;" class="challenge-badge"></div>
      <div id="q-text" style="font-size:1.3rem; margin:15px 0;"></div>
      
      <div id="q-img-container"></div>
      <div id="qr-box" style="display:none;" class="qr-container">
        <p style="color:#000; font-weight:bold; font-size:0.9rem; margin-bottom:8px;">امسح الباركود بجوالك لمعرفة الكلمة والشرح:</p>
        <img id="qr-img" src="" alt="QR Code">
      </div>

      <div class="a-text" id="a-text"></div>
      <div>
        <button class="btn" style="background:var(--gold); color:#000;" onclick="document.getElementById('a-text').style.display='block'">عرض الإجابة</button>
        <button class="btn" style="background:#0984e3;" onclick="addPoints(1)">نقاط لـ <span id="btn-t1"></span></button>
        <button class="btn" style="background:#d63031;" onclick="addPoints(2)">نقاط لـ <span id="btn-t2"></span></button>
        <button class="btn" style="background:#636e72;" onclick="addPoints(0)">إغلاق</button>
      </div>
    </div>
  </div>

</div>